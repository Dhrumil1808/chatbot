wget -c --no-check-certificate  http://www.mpi-sws.org/~cristian/data/cornell_movie_dialogs_corpus.zip
